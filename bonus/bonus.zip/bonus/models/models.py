from odoo import models, fields, api

class EmployeeBonus(models.Model):
    _name = 'hr.employee.bonus'
    _description = 'Bonos para Empleados'

    # Definir el nombre del bono y su valor
    name = fields.Selection([
        ('orden_y_limpieza', 'Bono por Orden y Limpieza en el Área'),
        ('puntualidad', 'Bono por Puntualidad'),
        ('asistencia_completa', 'Bono por Asistencia Completa (sin faltas en el mes)'),
        ('proactividad', 'Bono por Proactividad (aportó ideas o soluciones)'),
        ('trabajo_en_equipo', 'Bono por Trabajo en Equipo (colaboró de forma destacada)'),
        ('calidad_trabajo', 'Bono por Calidad en el Trabajo (entregó sin errores o revisiones)'),
        ('actitud_positiva', 'Bono por Actitud Positiva (buen ambiente y energía)'),
        ('cumplimiento_metas', 'Bono por Cumplimiento de Metas Diarias'),
        ('uso_eficiente_tiempo', 'Bono por Uso Eficiente del Tiempo (sin distracciones)'),
        ('responsabilidad_tareas', 'Bono por Responsabilidad en Tareas Asignadas')
    ], string='Tipo de Bono', required=True)

    value = fields.Float(string='Valor del Bono', required=True)

    employee_id = fields.Many2one('hr.employee', string='Empleado', required=True)

    # Constructor para asignar el valor de cada bono según el tipo
    @api.model
    def create(self, vals):
        """ Al crear un bono, asigna el valor de acuerdo al tipo de bono seleccionado. """
        bono_type = vals.get('name')  # Obtiene el tipo de bono seleccionado
        if bono_type:
            bono_values = {
                'orden_y_limpieza': 0.05,
                'puntualidad': 0.05,
                'asistencia_completa': 0.1,
                'proactividad': 0.05,
                'trabajo_en_equipo': 0.03,
                'calidad_trabajo': 0.07,
                'actitud_positiva': 0.02,
                'cumplimiento_metas': 0.05,
                'uso_eficiente_tiempo': 0.03,
                'responsabilidad_tareas': 0.1,
            }
            # Asigna el valor del bono basado en el tipo
            vals['value'] = bono_values.get(bono_type)
        return super(EmployeeBonus, self).create(vals)
