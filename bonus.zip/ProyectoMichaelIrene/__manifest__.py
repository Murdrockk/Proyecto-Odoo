# -*- coding: utf-8 -*-
{
    'name': "Bonos",
    'summary': "Módulo para asignar bonos.",
    'description': """
    Este módulo permite a las empresas asignar un reconocimiento económico a un empleado de manera ocasional, como incentivo o recompensa por su desempeño destacado, cumplimiento de metas, compromiso o contribución significativa.
    """,
    'author': "Irene y Michael",
    'website': "https://www.yourcompany.com",
    'category': 'Recursos Humanos',
    'version': '0.1',
    'depends': ['base', 'hr'],
    'data': [
        'security/ir.model.access.csv',  # Seguridad
        'views/employee_bonus_views.xml',  # Vista para los bonos de empleados
        'views/employee_bonus_menu.xml',  # Menú para la gestión de bonos
    ],
    'demo': [
        'demo/demo.xml',  # Datos de ejemplo
    ],
}
